      <?php
      # Get the Token from the api
      $token_options = array(
	    'http'=>array(
	      'method'=>"PUT",
	      'header'=>"X-aws-ec2-metadata-token-ttl-seconds: 21600"
	    )
      );
      $token_context=stream_context_create($token_options);
      $token=file_get_contents('http://169.254.169.254/latest/api/token',false,$token_context);

      $meta_options = array(
	    'http'=>array(
	      'method'=>"GET",
	      'header'=>"X-aws-ec2-metadata-token: $token"
	    )

      );
        # Retrieve settings from Parameter Store
        error_log('Retrieving settings');
        require 'aws-autoloader.php';

        $meta_context=stream_context_create($meta_options);
        
        $az = file_get_contents('http://169.254.169.254/latest/meta-data/placement/availability-zone',false,$meta_context);
        $region = substr($az, 0, -1);

        $ssm_client = new Aws\Ssm\SsmClient([
          'version' => 'latest',
          'region'  => $region
        ]);

        try {
          # Retrieve settings from Parameter Store
          $result = $ssm_client->GetParametersByPath(['Path' => '/inventory-app/', 'WithDecryption' => true]);

          # Extract individual parameters
          foreach($result['Parameters'] as $p) {
              $values[$p['Name']] = $p['Value'];
          }

          $ep = $values['/inventory-app/endpoint'];
          $un = $values['/inventory-app/username'];
          $pw = $values['/inventory-app/password'];
          $db = $values['/inventory-app/db'];
        }
        catch (Exception $e) {
          $ep = '';
          $db = '';
          $un = '';
          $pw = '';
        }
      #error_log('Settings are: ' . $ep. " / " . $db . " / " . $un . " / " . $pw);
      ?>
